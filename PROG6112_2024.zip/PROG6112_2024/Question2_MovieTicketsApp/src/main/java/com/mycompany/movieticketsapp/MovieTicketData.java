package com.mycompany.movieticketsapp;

/**
 * Holds the details captured on the form for one ticket purchase.
 * Passed to MovieTickets.ValidateData() as required by the IMovieTickets interface.
 */
public class MovieTicketData {

    private final String movieName;
    private final int numberOfTickets;
    private final double ticketPrice;

    public MovieTicketData(String movieName, int numberOfTickets, double ticketPrice) {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }

    public String getMovieName() {
        return movieName;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }
}
