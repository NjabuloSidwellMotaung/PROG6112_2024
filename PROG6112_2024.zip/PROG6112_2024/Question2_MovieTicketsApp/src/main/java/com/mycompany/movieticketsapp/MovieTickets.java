package com.mycompany.movieticketsapp;

/**
 * Q.2.7 - Calculates the total ticket price (including VAT) and validates the captured data.
 */
public class MovieTickets implements IMovieTickets {

    // South African VAT rate used by the cinema
    public static final double VAT_RATE = 0.14;

    /**
     * Total = tickets x price, plus 14% VAT.
     * Rounded to 2 decimals so floating-point noise (e.g. 341.99999...) never shows up.
     */
    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double subtotal = numberOfTickets * ticketPrice;
        double total = subtotal + (subtotal * VAT_RATE);
        return Math.round(total * 100.0) / 100.0;
    }

    /**
     * Returns true only when every validation rule passes.
     */
    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        return GetValidationError(movieTicketData) == null;
    }

    /**
     * Checks each rule from the question and returns a message for the first one that fails,
     * or null when the data is valid. The GUI uses the message to tell the user what to fix.
     */
    public String GetValidationError(MovieTicketData movieTicketData) {
        if (movieTicketData.getMovieName() == null || movieTicketData.getMovieName().isBlank()) {
            return "Movie name cannot be empty.";
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            return "Ticket price must be greater than zero.";
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return "Number of tickets must be greater than zero.";
        }
        return null;
    }
}
