package com.mycompany.movieticketsapp;

/**
 * Q.2.8 - Contract for the movie ticket calculations and validation.
 */
public interface IMovieTickets {

    double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice);

    boolean ValidateData(MovieTicketData movieTicketData);
}
