package com.mycompany.movieticketsapp;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Q.2.1 - Q.2.6: GUI that captures a movie ticket purchase, shows the report and saves it to report.txt.
 */
public class MovieTicketsApp extends JFrame {

    private static final String FILE_NAME = "report.txt";
    private static final String DIVIDER = "**********************************";

    // Q.2.1 - form controls
    private final JComboBox<String> cboMovie = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
    private final JTextField txtNumberOfTickets = new JTextField(12);
    private final JTextField txtTicketPrice = new JTextField(12);
    private final JTextArea txtReport = new JTextArea(5, 25);

    private final MovieTickets movieTickets = new MovieTickets();

    public MovieTicketsApp() {
        super("MOVIE TICKETS");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setJMenuBar(createMenuBar());
        add(createContentPanel());

        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Q.2.2 - File (Exit) and Tools (Process, Clear) menus.
     */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));   // Q.2.3
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        processItem.addActionListener(e -> processTickets());
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    /**
     * Q.2.1 - Labels and inputs in a grid, with the read-only report area underneath.
     */
    private JPanel createContentPanel() {
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 12));
        inputPanel.add(new JLabel("MOVIE:"));
        inputPanel.add(cboMovie);
        inputPanel.add(new JLabel("NUMBER OF TICKETS:"));
        inputPanel.add(txtNumberOfTickets);
        inputPanel.add(new JLabel("TICKET PRICE:"));
        inputPanel.add(txtTicketPrice);
        inputPanel.add(new JLabel("TICKET REPORT:"));

        txtReport.setEditable(false);   // read-only as required

        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(txtReport), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Q.2.4 - Captures and validates the input, displays the report, then saves it (Q.2.5).
     */
    private void processTickets() {
        String movieName = (String) cboMovie.getSelectedItem();
        int numberOfTickets;
        double ticketPrice;

        // Text fields hold text, so check that numbers were actually typed in
        try {
            numberOfTickets = Integer.parseInt(txtNumberOfTickets.getText().trim());
            ticketPrice = Double.parseDouble(txtTicketPrice.getText().trim());
        } catch (NumberFormatException ex) {
            showError("Enter a whole number for tickets and a numeric value for the ticket price.");
            return;
        }

        // Only valid data is captured (Q.2.7)
        MovieTicketData data = new MovieTicketData(movieName, numberOfTickets, ticketPrice);
        if (!movieTickets.ValidateData(data)) {
            showError(movieTickets.GetValidationError(data));
            return;
        }

        double totalPrice = movieTickets.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);

        String report = "MOVIE NAME: " + movieName + "\n"
                + "MOVIE TICKET PRICE: R " + ticketPrice + "\n"
                + "NUMBER OF TICKETS: " + numberOfTickets + "\n"
                + "TOTAL TICKET PRICE: R " + totalPrice;

        txtReport.setText(report);
        saveReport(report);
    }

    /**
     * Q.2.5 - Writes the report to report.txt in the format of the sample file.
     */
    private void saveReport(String report) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            writer.println("MOVIE TICKET REPORT");
            writer.println(DIVIDER);
            writer.println(report);
            writer.println(DIVIDER);
        } catch (IOException ex) {
            showError("Could not save " + FILE_NAME + ": " + ex.getMessage());
        }
    }

    /**
     * Q.2.6 - Puts the form back to its default state.
     */
    private void clearForm() {
        cboMovie.setSelectedIndex(0);
        txtNumberOfTickets.setText("");
        txtTicketPrice.setText("");
        txtReport.setText("");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Invalid input", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        // Swing components must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new MovieTicketsApp().setVisible(true));
    }
}
