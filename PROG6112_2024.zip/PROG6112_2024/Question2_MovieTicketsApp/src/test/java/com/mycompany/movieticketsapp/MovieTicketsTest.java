package com.mycompany.movieticketsapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;

/**
 * Q.2.9 - Unit tests for the MovieTickets class.
 */
public class MovieTicketsTest {

    private MovieTickets movieTickets;

    @Before
    public void setUp() {
        movieTickets = new MovieTickets();
    }

    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        // 3 tickets x R100 = R300, plus 14% VAT = R342.00
        double expected = 342.0;
        double actual = movieTickets.CalculateTotalTicketPrice(3, 100);
        assertEquals(expected, actual, 0.001);
    }

    @Test
    public void ValidateData_NumberOfTicketsNotValid_ReturnsFalse() {
        // Zero tickets breaks the rule "cannot be less than or equal to zero"
        MovieTicketData data = new MovieTicketData("Napoleon", 0, 100);
        assertFalse(movieTickets.ValidateData(data));
    }
}
