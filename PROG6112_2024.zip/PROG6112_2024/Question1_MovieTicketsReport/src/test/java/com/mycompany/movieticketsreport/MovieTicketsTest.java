package com.mycompany.movieticketsreport;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Q.1.3 - Unit tests for the MovieTickets class.
 */
public class MovieTicketsTest {

    private MovieTickets movieTickets;

    @Before
    public void setUp() {
        movieTickets = new MovieTickets();
    }

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        // Napoleon: 3000 + 1500 + 1700 = 6200
        int[] napoleonSales = {3000, 1500, 1700};
        int expected = 6200;
        int actual = movieTickets.TotalMovieSales(napoleonSales);
        assertEquals(expected, actual);
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Oppenheimer (6300) beats Napoleon (6200)
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};
        String expected = "Oppenheimer";
        String actual = movieTickets.TopMovie(movies, totalSales);
        assertEquals(expected, actual);
    }
}
