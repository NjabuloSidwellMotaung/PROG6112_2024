package com.mycompany.movieticketsreport;

/**
 * Q.1.2 - Contract for the movie ticket calculations.
 */
public interface IMovieTickets {

    int TotalMovieSales(int[] movieTicketSales);

    String TopMovie(String[] movies, int[] totalSales);
}
