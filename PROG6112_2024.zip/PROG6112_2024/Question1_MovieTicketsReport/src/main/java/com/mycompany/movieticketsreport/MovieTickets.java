package com.mycompany.movieticketsreport;

/**
 * Q.1.2 - Calculates the total ticket sales for a movie and finds the top performing movie.
 */
public class MovieTickets implements IMovieTickets {

    /**
     * Adds up the monthly ticket sales for ONE movie.
     * The report passes in one row of the 2D array (e.g. Napoleon's JAN, FEB, MAR sales).
     */
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

    /**
     * Returns the name of the movie with the highest total sales.
     * movies[i] and totalSales[i] refer to the same movie, so the index links them.
     */
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
        return movies[topIndex];
    }
}
