package com.mycompany.movieticketsreport;

/**
 * Q.1.1 - Prints the movie ticket sales report for January to March 2024.
 * Single-dimensional arrays hold the movie names, month headings and totals.
 * A two-dimensional array holds the ticket sales: rows = movies, columns = months.
 */
public class MovieTicketsReport {

    public static void main(String[] args) {

        // Single-dimensional arrays
        String[] movies = {"Napoleon", "Oppenheimer"};
        String[] months = {"JAN", "FEB", "MAR"};

        // Two-dimensional array: [movie][month]
        int[][] ticketSales = {
            {3000, 1500, 1700},   // Napoleon
            {3500, 1200, 1600}    // Oppenheimer
        };

        MovieTickets movieTickets = new MovieTickets();

        // Work out each movie's total and store it in a single-dimensional array
        int[] totalSales = new int[movies.length];
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(ticketSales[i]);
        }

        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println();

        // Column headings
        System.out.printf("%-20s", "");
        for (String month : months) {
            System.out.printf("%-12s", month);
        }
        System.out.println();
        System.out.println("-------------------------------------------------------------");

        // One row per movie: name followed by its monthly sales
        for (int row = 0; row < ticketSales.length; row++) {
            System.out.printf("%-20s", movies[row]);
            for (int col = 0; col < ticketSales[row].length; col++) {
                System.out.printf("%-12d", ticketSales[row][col]);
            }
            System.out.println();
        }
        System.out.println();

        // Total ticket sales for each movie
        for (int i = 0; i < movies.length; i++) {
            System.out.println("Total movie ticket sales for " + movies[i] + " " + totalSales[i]);
        }
        System.out.println();

        // Top performing movie
        System.out.println("Top performing movie: " + movieTickets.TopMovie(movies, totalSales));
    }
}
