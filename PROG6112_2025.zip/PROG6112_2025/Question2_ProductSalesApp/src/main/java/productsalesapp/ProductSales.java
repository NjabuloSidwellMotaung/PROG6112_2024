package productsalesapp;

/**
 * Holds the product sales data in memory and performs all calculations (Q.2.4).
 * Rows = years, columns = products (Microphone, Speakers, Mixing Desk).
 */
public class ProductSales implements IProductSales {

    // A product is a success when its sales are above this limit
    public static final int SALES_LIMIT = 500;

    private final int[][] productSales;

    /**
     * Default constructor loads the sales data supplied in the question.
     */
    public ProductSales() {
        this(new int[][]{
            {300, 150, 700},   // Year 1: Microphone, Speakers, Mixing Desk
            {250, 200, 600}    // Year 2: Microphone, Speakers, Mixing Desk
        });
    }

    /**
     * Allows different data to be supplied, which makes the class easy to unit test.
     */
    public ProductSales(int[][] productSales) {
        this.productSales = productSales;
    }

    @Override
    public int[][] GetProductSales() {
        return productSales;
    }

    /**
     * Adds every sales value across all years and products.
     */
    @Override
    public int GetTotalSales() {
        int total = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                total += sale;
            }
        }
        return total;
    }

    /**
     * Counts the sales values that are above the sales limit.
     */
    @Override
    public int GetSalesOverLimit() {
        int count = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale > SALES_LIMIT) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Counts the sales values that are at or below the sales limit.
     * Over + under always equals the total number of sales values.
     */
    @Override
    public int GetSalesUnderLimit() {
        return GetSalesCount() - GetSalesOverLimit();
    }

    /**
     * Number of years processed = number of rows in the array.
     */
    @Override
    public int GetProductsProcessed() {
        return productSales.length;
    }

    /**
     * Average of all sales values. Returns 0 when there is no data.
     */
    @Override
    public double GetAverageSales() {
        int count = GetSalesCount();
        if (count == 0) {
            return 0;
        }
        return (double) GetTotalSales() / count;
    }

    /**
     * Helper: total number of individual sales values in the array.
     */
    private int GetSalesCount() {
        int count = 0;
        for (int[] year : productSales) {
            count += year.length;
        }
        return count;
    }
}
