package productsalesapp;

/**
 * Contract for the sound equipment product sales calculations (Q.2.4).
 */
public interface IProductSales {

    int[][] GetProductSales();

    int GetTotalSales();

    int GetSalesOverLimit();

    int GetSalesUnderLimit();

    int GetProductsProcessed();

    double GetAverageSales();
}
