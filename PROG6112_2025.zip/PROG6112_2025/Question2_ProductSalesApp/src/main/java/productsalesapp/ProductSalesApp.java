package productsalesapp;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 * Q.2.1 - Q.2.3: GUI application for the sound equipment retailer.
 * Loads the product sales data, shows the results in a text area and saves them to data.txt.
 */
public class ProductSalesApp extends JFrame {

    private static final String FILE_NAME = "data.txt";
    private static final String DIVIDER = "**********************************";

    private final JTextArea txtSalesData = new JTextArea(5, 22);
    private final JLabel lblYearsProcessed = new JLabel("Years Processed: ");

    public ProductSalesApp() {
        super("Product Sales Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setJMenuBar(createMenuBar());
        add(createContentPanel());

        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Q.2.3 - Builds the File and Tools menus.
     * The Load and Save menu items call the same methods as the buttons.
     */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        // Tools menu
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");
        loadItem.addActionListener(e -> loadProductData());
        saveItem.addActionListener(e -> saveProductData());
        clearItem.addActionListener(e -> clearData());
        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    /**
     * Q.2.1 - Two buttons, a read-only text area and the Years Processed label.
     */
    private JPanel createContentPanel() {
        JButton btnLoad = new JButton("Load Product Data");
        JButton btnSave = new JButton("Save Product Data");
        btnLoad.addActionListener(e -> loadProductData());
        btnSave.addActionListener(e -> saveProductData());

        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 8));
        buttonPanel.add(btnLoad);
        buttonPanel.add(btnSave);

        // The user must not type into the results area
        txtSalesData.setEditable(false);
        txtSalesData.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(txtSalesData);
        scrollPane.setPreferredSize(new Dimension(260, 100));

        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(lblYearsProcessed, BorderLayout.SOUTH);
        return panel;
    }

    /**
     * Q.2.2 - Loads the data from memory, runs the calculations and displays the results.
     */
    private void loadProductData() {
        ProductSales sales = new ProductSales();

        // Average is rounded to a whole number to match the sample (366.67 -> 367)
        String report = "Total Sales: " + sales.GetTotalSales() + "\n"
                + "Average Sales: " + Math.round(sales.GetAverageSales()) + "\n"
                + "Sales over limit: " + sales.GetSalesOverLimit() + "\n"
                + "Sales under limit: " + sales.GetSalesUnderLimit();

        txtSalesData.setText(report);
        lblYearsProcessed.setText("Years Processed: " + sales.GetProductsProcessed());
    }

    /**
     * Q.2.2 - Writes the text area contents to data.txt in the format of the sample file.
     * try-with-resources closes the file automatically, even if an error occurs.
     */
    private void saveProductData() {
        if (txtSalesData.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Load the product data before saving.",
                    "Nothing to save", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            writer.println("DATA LOG");
            writer.println(DIVIDER);
            writer.println(txtSalesData.getText());
            writer.println(DIVIDER);
            JOptionPane.showMessageDialog(this, "Product data saved to " + FILE_NAME);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save the file: " + ex.getMessage(),
                    "Save error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Q.2.3 - Clears the text area and the Years Processed label.
     */
    private void clearData() {
        txtSalesData.setText("");
        lblYearsProcessed.setText("Years Processed: ");
    }

    public static void main(String[] args) {
        // Swing components must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new ProductSalesApp().setVisible(true));
    }
}
