package productsalesapp;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Q.2.5 - Unit tests for the ProductSales class.
 */
public class ProductSalesTest {

    private ProductSales productSales;

    @Before
    public void setUp() {
        // Same data as the question: 700 and 600 are above the limit of 500
        productSales = new ProductSales(new int[][]{
            {300, 150, 700},
            {250, 200, 600}
        });
    }

    @Test
    public void GetSalesOverLimit_ReturnsNumberOfSales() {
        int expected = 2;
        int actual = productSales.GetSalesOverLimit();
        assertEquals(expected, actual);
    }

    @Test
    public void GetSalesUnderLimit_ReturnsNumberOfSales() {
        int expected = 4;
        int actual = productSales.GetSalesUnderLimit();
        assertEquals(expected, actual);
    }
}
