package productsalesreport;

/**
 * Q.1.1 - Prints the product sales report for a local retail company.
 * Single-dimensional arrays hold the row and column headings,
 * and a two-dimensional array holds the quarterly sales figures for two years.
 */
public class ProductSalesReport {

    public static void main(String[] args) {

        // Single-dimensional arrays: headings for the rows and columns of the report
        String[] years = {"YEAR 1", "YEAR 2"};
        String[] quarters = {"QUARTER 1", "QUARTER 2", "QUARTER 3"};

        // Two-dimensional array: [year][quarter]
        int[][] productSales = {
            {300, 150, 700},
            {250, 200, 600}
        };

        // All calculations are handled by the ProductSales class
        ProductSales sales = new ProductSales();

        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("=================================================");

        // Print the column headings
        System.out.printf("%-10s", "");
        for (String quarter : quarters) {
            System.out.printf("%-13s", quarter);
        }
        System.out.println();

        // Print each row: year label followed by its quarterly sales
        for (int row = 0; row < productSales.length; row++) {
            System.out.printf("%-10s", years[row]);
            for (int col = 0; col < productSales[row].length; col++) {
                System.out.printf("%-13d", productSales[row][col]);
            }
            System.out.println();
        }

        System.out.println("=================================================");

        // Print the summary figures for the two-year period
        System.out.printf("Total sales for 2 years:   %d%n", sales.TotalSales(productSales));
        System.out.printf("Average sales for 2 years: %.0f%n", sales.AverageSales(productSales));
        System.out.printf("Maximum sale for 2 years:  %d%n", sales.MaxSale(productSales));
        System.out.printf("Minimum sale for 2 years:  %d%n", sales.MinSale(productSales));
        System.out.println("=================================================");
    }
}
