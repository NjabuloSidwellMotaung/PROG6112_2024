package productsalesreport;

/**
 * Performs the sales calculations defined in the IProduct interface (Q.1.2).
 * Every method loops through each row (year) and each column (quarter) of the 2D array.
 */
public class ProductSales implements IProduct {

    /**
     * Adds up every sales value in the array.
     */
    @Override
    public int TotalSales(int[][] productSales) {
        int total = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                total += sale;
            }
        }
        return total;
    }

    /**
     * Average = total sales divided by the number of sales values.
     * The count is worked out from the array so the method still works if more years are added.
     */
    @Override
    public double AverageSales(int[][] productSales) {
        int count = 0;
        for (int[] year : productSales) {
            count += year.length;
        }
        // Guard against division by zero when no data is supplied
        if (count == 0) {
            return 0;
        }
        return (double) TotalSales(productSales) / count;
    }

    /**
     * Returns the highest single sales value.
     * Starts from the first value so negative or zero data is still handled correctly.
     */
    @Override
    public int MaxSale(int[][] productSales) {
        int max = productSales[0][0];
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale > max) {
                    max = sale;
                }
            }
        }
        return max;
    }

    /**
     * Returns the lowest single sales value.
     */
    @Override
    public int MinSale(int[][] productSales) {
        int min = productSales[0][0];
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale < min) {
                    min = sale;
                }
            }
        }
        return min;
    }
}
