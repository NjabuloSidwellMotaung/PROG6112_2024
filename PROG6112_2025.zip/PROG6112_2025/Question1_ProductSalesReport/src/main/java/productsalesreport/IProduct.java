package productsalesreport;

/**
 * Contract for the product sales calculations (Q.1.2).
 * Each method receives the sales data as a 2D array: rows = years, columns = quarters.
 */
public interface IProduct {

    int TotalSales(int[][] productSales);

    double AverageSales(int[][] productSales);

    int MaxSale(int[][] productSales);

    int MinSale(int[][] productSales);
}
