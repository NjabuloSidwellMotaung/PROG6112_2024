/*Question1_ProductSalesReport */
package productsalesreport;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Q.1.3 - Unit tests for the ProductSales class.
 */
public class ProductSalesTest {

    private ProductSales productSales;
    private int[][] salesData;

    // Runs before every test so each test starts with fresh data
    @Before
    public void setUp() {
        productSales = new ProductSales();
        salesData = new int[][]{
            {300, 150, 700},
            {250, 200, 600}
        };
    }

    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
        // 300 + 150 + 700 + 250 + 200 + 600 = 2200
        int expected = 2200;
        int actual = productSales.TotalSales(salesData);
        assertEquals(expected, actual);
    }

    @Test
    public void AverageSales_ReturnsAverageProductSales() {
        // 2200 / 6 = 366.67
        double expected = 2200.0 / 6;
        double actual = productSales.AverageSales(salesData);
        assertEquals(expected, actual, 0.01);
    }
}
